package com.emtronik.domains;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long eid;
	private String ename;
	private LocalDate ehiredate;
	private Double esalary;
	private String etype;
	
	@ManyToOne
	@JoinColumn(name = "did")
	private EmpDepartment emdepart;
	
	
	public Long getEid() {
		return eid;
	}
	public void setEid(Long eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public LocalDate getEhiredate() {
		return ehiredate;
	}
	public void setEhiredate(LocalDate ehiredate) {
		this.ehiredate = ehiredate;
	}
	
	
	public Double getEsalary() {
		return esalary;
	}
	public void setEsalary(Double esalary) {
		this.esalary = esalary;
	}
	
	public String getEtype() {
		return etype;
	}
	public void setEtype(String etype) {
		this.etype = etype;
	}
	public EmpDepartment getEmdepart() {
		return emdepart;
	}
	public void setEmdepart(EmpDepartment emdepart) {
		this.emdepart = emdepart;
	}
	
	
	
	
	

}
