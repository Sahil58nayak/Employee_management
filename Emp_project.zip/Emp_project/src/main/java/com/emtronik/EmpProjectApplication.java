package com.emtronik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpProjectApplication.class, args);
	}

}
