package com.emtronik.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emtronik.domains.Employee;

public interface EmpRepo extends JpaRepository<Employee, Long> {

}
