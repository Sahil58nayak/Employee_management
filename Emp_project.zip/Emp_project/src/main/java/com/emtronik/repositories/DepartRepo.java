package com.emtronik.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emtronik.domains.EmpDepartment;

public interface DepartRepo extends JpaRepository<EmpDepartment, Long> {

	public EmpDepartment findByDname(String dname);
	
}
