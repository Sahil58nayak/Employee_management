package com.emtronik.services;

import java.util.List;

import com.emtronik.domains.Employee;

public interface EmpService {
	
	public String insert(Employee emp1);
	
	public List<Employee> select();
	
	public Employee getOne(Long eid);
	public void delete(Long eid);

}
