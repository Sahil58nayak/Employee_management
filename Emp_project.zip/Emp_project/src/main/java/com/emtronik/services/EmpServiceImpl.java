package com.emtronik.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emtronik.domains.EmpDepartment;
import com.emtronik.domains.Employee;
import com.emtronik.repositories.DepartRepo;
import com.emtronik.repositories.EmpRepo;

@Service
public class EmpServiceImpl implements EmpService {
	
	public EmpServiceImpl() {
		System.out.println("EmpServiceImpl...");
	}
	
	@Autowired
	private EmpRepo erepo;
	
	@Autowired
	private DepartRepo drepo;
	
	
	
	public String insert(Employee  emp1) {
		EmpDepartment d1 = drepo.findByDname(emp1.getEmdepart().getDname());
		
		emp1.setEmdepart(d1);
		
		erepo.save(emp1);
		
		if(emp1.getEid() != null) {
			return "Inserted Success";
		}else {
			return "Not Inserted";
		}
		
		
	}
	
	
	public List<Employee> select(){
		return erepo.findAll();
	}
	
	
	public Employee getOne(Long eid) {
		return erepo.findById(eid).get();
	 
	
}
	
	public void delete(Long eid) {
		erepo.deleteById(eid);
	}
	
	

}
