package com.emtronik.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.emtronik.domains.Employee;
import com.emtronik.services.EmpService;

@Controller
public class MyController {

	
	public MyController() {
		System.out.println("Controller()..");
	}
	
	@Autowired
	private EmpService serv;
	
	@GetMapping("/")
	public String wel() {
		return "EmpRegistration";
	}
	
	@GetMapping("/reg")
	public String insertData(@ModelAttribute("key")Employee emp1) {
		serv.insert(emp1);
		return "redirect:show";
	}
	
	@GetMapping("/show")
	public String saveData(Model m) {
		List<Employee> es = serv.select();
		m.addAttribute("employee", es);
		return "EmpRegistration";
	
	}
	
	@GetMapping("/vie")
	public String one(@RequestParam("eid")Long eid, Model m) {
		Employee es=serv.getOne(eid);
		m.addAttribute("empl", es);
		return "ViewSingle";
	}
	
	@GetMapping("/showAll")
	public String saveAll(Model m) {
		List<Employee> es = serv.select();
		m.addAttribute("employee", es);
		return "AllData";
	
	}
	
	@GetMapping("/del")
	public String deleteData(@RequestParam("eid")Long eid) {
		serv.delete(eid);
		return "redirect:showAll";
	}
	
	
	
	
	
	
	
	
	
	
}
