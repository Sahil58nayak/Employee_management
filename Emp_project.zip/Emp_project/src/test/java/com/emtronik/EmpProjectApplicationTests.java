package com.emtronik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
