package com.emtronik.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import com.emtronik.domains.Doctor;

public interface DocRepo  extends JpaRepository<Doctor, Long>{
	
	
	
}
