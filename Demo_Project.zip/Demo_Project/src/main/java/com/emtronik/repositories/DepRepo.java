package com.emtronik.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.emtronik.domains.Department;

public interface DepRepo extends JpaRepository<Department, Long> {

	
	/* @Query("select s from department s where s.dname =:a") */
	
	
	public Department findByDname(String dname);
	
}
