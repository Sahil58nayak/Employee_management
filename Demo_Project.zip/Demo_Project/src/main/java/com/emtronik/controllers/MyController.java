package com.emtronik.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.emtronik.domains.Doctor;
import com.emtronik.domains.DoctorDto;
import com.emtronik.services.DcService;

@Controller
public class MyController {

	public MyController() {
		System.out.println("MyController....");
	}
	
	@Autowired
	private DcService serv; 
	
	
	@GetMapping("/")
	public String wel() {
		return "Registration";
		
	}
	
	@PostMapping("/reg")
	public String insert(@ModelAttribute("key")DoctorDto doc1, Model m) {
		String em =serv.insertData(doc1);
		m.addAttribute("rec", em);
		return "redirect:show";
	}
	
	@GetMapping("/show")
	public String select(Model m) {
		List<DoctorDto> dc = serv.saveData();
		m.addAttribute("doct", dc);
		return "Registration";
		
	}
	
	@GetMapping("/vie")
	public String selectOne(@RequestParam("dcid")Long dcid, Model m) {
		DoctorDto d = serv.getOned(dcid);
		m.addAttribute("sing", d);
		return "Single";
	}
	
	@GetMapping("/del")
	public String deletedata(@RequestParam("dcid")Long dcid) {
		serv.deleteData(dcid);
		return "redirect:showAll";
	}
	
	@GetMapping("/showAll")
	public String selectAll(Model m) {
		List<DoctorDto> dc = serv.saveData();
		m.addAttribute("doct", dc);
		return "AllData";
		
	}
	 
	
}
