package com.emtronik.domains;

import java.time.LocalDate;

public class DoctorDto {
	
	private Long dcid;
	private String dcname;
	private String dcgender;
	private String dctype;
	private Long dcmobile;
	private LocalDate hireDate;
	private String dname;
	
	
	public Long getDcid() {
		return dcid;
	}
	public void setDcid(Long dcid) {
		this.dcid = dcid;
	}
	public String getDcname() {
		return dcname;
	}
	public void setDcname(String dcname) {
		this.dcname = dcname;
	}
	public String getDcgender() {
		return dcgender;
	}
	public void setDcgender(String dcgender) {
		this.dcgender = dcgender;
	}
	public String getDctype() {
		return dctype;
	}
	public void setDctype(String dctype) {
		this.dctype = dctype;
	}
	public Long getDcmobile() {
		return dcmobile;
	}
	public void setDcmobile(Long dcmobile) {
		this.dcmobile = dcmobile;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	
	

}
