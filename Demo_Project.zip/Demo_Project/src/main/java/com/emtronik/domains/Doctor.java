package com.emtronik.domains;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Doctor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long dcid;
	private String dcname;
	private String dcgender;
	private String dctype;
	private Long dcmobile;
	private LocalDate hireDate;
	
	
	@ManyToOne
	@JoinColumn(name = "did")
	private Department depart;
	

	
	public Long getDcid() {
		return dcid;
	}

	public void setDcid(Long dcid) {
		this.dcid = dcid;
	}

	public String getDcname() {
		return dcname;
	}

	public void setDcname(String dcname) {
		this.dcname = dcname;
	}

	public String getDcgender() {
		return dcgender;
	}

	public void setDcgender(String dcgender) {
		this.dcgender = dcgender;
	}

	public String getDctype() {
		return dctype;
	}

	public void setDctype(String dctype) {
		this.dctype = dctype;
	}

	

	public Long getDcmobile() {
		return dcmobile;
	}

	public void setDcmobile(Long dcmobile) {
		this.dcmobile = dcmobile;
	}

	

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	

	
	public Department getDepart() {
		return depart;
	}

	public void setDepart(Department depart) {
		this.depart = depart;
	}

	
	

}
