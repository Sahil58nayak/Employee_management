package com.emtronik.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emtronik.domains.Department;
import com.emtronik.domains.Doctor;
import com.emtronik.domains.DoctorDto;
import com.emtronik.repositories.DepRepo;
import com.emtronik.repositories.DocRepo;


@Service
public class DcServiceImpl implements DcService {
	
	public DcServiceImpl() {
		System.out.println("DcServiceImpl..");
	}
	
	@Autowired
	private DepRepo dep;
	
	@Autowired
	private DocRepo doc;
	
	
	public String insertData(DoctorDto doc1) {  
		
		Department dept = dep.findByDname(doc1.getDname());
		
		/*
		 * Departments dep =
		 * depRepo.findById(employee.getDepartment().getDept_id()).get();
		 */
		
		Doctor dt = new Doctor();
		
		dt.setDepart(dept);
		
		BeanUtils.copyProperties(doc1, dt);
		
		    doc.save(dt);
		
			if(dt.getDcid() !=null) 
		{
				
			return "record insert";
			
		}else {
			
			return "not insert";
		}
	}
	
	public List<DoctorDto> saveData(){
		
		List<DoctorDto> doct = new ArrayList<>();
		
		List<Doctor> dt = doc.findAll();
		
		for(Doctor d : dt ) {
			
			DoctorDto dc = new DoctorDto();
			
			dc.setDname(d.getDepart().getDname());
			
			BeanUtils.copyProperties(d, dc);
			
			doct.add(dc);
			
		}
			return doct;
	}
 	 
	  
	  
	  public DoctorDto getOned(Long dcid) { 
		  
		 Doctor d = doc.findById(dcid).get();
		 
		 DoctorDto drr = new DoctorDto();
		 drr.setDname(d.getDepart().getDname());
		 
		 BeanUtils.copyProperties(d, drr);
		 
		   return drr;
	  
	  } 
	  
	  public void deleteData(Long dcid) {
		  doc.deleteById(dcid);
		  
	  }
	  
	 
	
	
	
	
	
		
		
	

}
