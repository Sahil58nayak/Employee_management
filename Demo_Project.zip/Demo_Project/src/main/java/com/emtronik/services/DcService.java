package com.emtronik.services;

import java.util.List;

import com.emtronik.domains.Doctor;
import com.emtronik.domains.DoctorDto;

public interface DcService {

	
	public String insertData(DoctorDto doc1);
	public List<DoctorDto> saveData();
	public void deleteData(Long dcid);
	public DoctorDto getOned(Long dcid);
	
}
