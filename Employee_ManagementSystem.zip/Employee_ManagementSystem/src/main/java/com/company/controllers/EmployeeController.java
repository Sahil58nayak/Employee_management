package com.company.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.company.domains.Employee2;
import com.company.services.EmployeeService;

@Controller
public class EmployeeController {

	public EmployeeController() {
		
		System.out.println("MyController....");
	}

	@Autowired
	public EmployeeService ser;
	
	
	
	@GetMapping("/")
	public String insert() {
		return "Registration";
	
	}
	
	@PostMapping("/reg")
	public String stored(@ModelAttribute("key")Employee2 emp1) {
		
		System.out.println("insert()...");
		
		ser.insertData(emp1);
		
		System.out.println(emp1.getEid()+""+emp1.getEname());
		return "redirect:show";
	}
	
	
	@GetMapping("/show")
	public String showw (Model m) {
		
		System.out.println("showw All()...");
		
	List<Employee2> ess=ser.selectData();
	
	System.out.println(ess);
	m.addAttribute("employee", ess);
	return "ShowAll";
	}
	
	@GetMapping("/upd")
	public String update(@RequestParam("eid")Integer eid, Model m) {
		
		System.out.println("get one()...");
		Employee2 es=ser.getOne(eid);
		
		System.out.println(eid);
		m.addAttribute("emp",es);
		
		return "Edit";
	}
	
	@PostMapping("/update")
	public String updatecop(@ModelAttribute("key")Employee2 emp2) {
		System.out.println("updated()....");
		ser.updateData(emp2);
		
		System.out.println(emp2.getEname()+""+emp2.getEaddr());
		
		return "redirect:show";
	}
	
	
	
	@GetMapping("/del")
	public String delete(@RequestParam("eid")Integer eid) {
		
		ser.deleteData(eid);
		System.out.println(eid);
		
		return "redirect:show";
	}
	
	
}
