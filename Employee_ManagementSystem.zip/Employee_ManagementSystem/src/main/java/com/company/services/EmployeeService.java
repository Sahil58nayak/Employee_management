package com.company.services;

import java.util.List;

import com.company.domains.Employee2;

public interface EmployeeService {
	
	public void insertData(Employee2 emp1);

public void updateData(Employee2 emp2);
public void deleteData(Integer eid);
public List<Employee2> selectData();
public Employee2 getOne(Integer eid);
	

}
