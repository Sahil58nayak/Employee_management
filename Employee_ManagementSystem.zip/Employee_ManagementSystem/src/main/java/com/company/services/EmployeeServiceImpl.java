package com.company.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.domains.Employee2;
import com.company.repositories.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	public EmployeeServiceImpl() {
		System.out.println("MyServiceImpl....");
	}

	@Autowired
	public EmployeeRepo repo;
	
	public void insertData(Employee2 emp1) {
		
		System.out.println(emp1.getEid()+""+emp1.getEname());
		repo.save(emp1);
	}
	
	public void updateData(Employee2 emp2) {
		
       System.out.println(emp2.getEid());		
		repo.save(emp2);
	}
	
	public void deleteData(Integer eid) {
		
		System.out.println(eid);
		repo.deleteById(eid);
	}
	
	public List<Employee2> selectData(){
		
		List<Employee2> ess=repo.findAll();
		
		System.out.println(ess);
		return ess;
	}
	
	public Employee2 getOne(Integer eid){
		
		Employee2 es=repo.findById(eid).get();
		
		System.out.println(es.getEname()+""+es.getEaddr());
		return es;
	}
}
