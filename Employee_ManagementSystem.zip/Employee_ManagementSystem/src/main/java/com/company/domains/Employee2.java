package com.company.domains;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee2 {

	@Id
	private Integer eid;
	private String ename;
	private String Eaddr;
	private String egenders;
	private String einterests;
	
	public Integer getEid() {
		return eid;
	}
	public void setEid(Integer eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEaddr() {
		return Eaddr;
	}
	public void setEaddr(String eaddr) {
		Eaddr = eaddr;
	}
	public String getEgenders() {
		return egenders;
	}
	public void setEgenders(String egenders) {
		this.egenders = egenders;
	}
	public String getEinterests() {
		return einterests;
	}
	public void setEinterests(String einterests) {
		this.einterests = einterests;
	}
	
}
